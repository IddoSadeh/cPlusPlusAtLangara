/* Lab 5-Problem #3 sum
 sum.cpp: we will write a function  which receives two integers i1 and i2 as parameters, and calculates and returns the sum of integers from i1 to i2
 Author: Iddo Sadeh Date: October 9, 2020*/
#include <iostream>
#include <cmath> /* here we include cmath to import the library which will let us usefunctions such as M_PI and pow*/
#include <iomanip> /*here we import the library which includes functions such as setpercision() and fixed*/
#include <stdlib.h>  // here we import a library that lets us use the rand funciton
#include <ctime> // here we import a library that will let us use time() function
#include<string> // here we import a library that will let us use functions such as getLine()
#include <fstream>// here we import a library which lets us read and write files

using namespace std;

int sum(int i1, int i2)
{
	int a = i1;
	while (i1 < i2)
	{
		i1++;
		a += i1;
	}
	return a;
}



int main()
{
	int num1, num2;
	cout << "this program will help you calculate the sum of all the integers between 2 integars you input, please input the first integer: " << endl;
	cin >> num1;
	cout << "please enter the second integer" << endl;
	cin >> num2;
	cout << sum(min(num1, num2), max(num1, num2));
}