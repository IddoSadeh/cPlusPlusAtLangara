/* Lab 5-Problem #2 temperature
 temprature.cpp: we will write a function that helps us reutrn a wind chill temparture from an input of temperature and wind speed
 Author: Iddo Sadeh Date: October 9, 2020*/
#include <iostream>
#include <cmath> /* here we include cmath to import the library which will let us usefunctions such as M_PI and pow*/
#include <iomanip> /*here we import the library which includes functions such as setpercision() and fixed*/
#include <stdlib.h>  // here we import a library that lets us use the rand funciton
#include <ctime> // here we import a library that will let us use time() function
#include<string> // here we import a library that will let us use functions such as getLine()
#include <fstream>// here we import a library which lets us read and write files

using namespace std;


double windChill(double temp, double wspeed)//Parameters are double, Returned Value is of type double
{
	return 35.74 + 0.6215 * temp - 35.75 * pow(wspeed, 0.16) + 0.4275 * temp * pow(wspeed, 0.16);
}


int main()
{
	double temp, wspeed;
	cout << "this program will help you understand what the temparature with wind chill is at any given moment" << endl << "please enter the temperature in Farenheit (temperature needs to be between -58 F and 41F):";
	cin >> temp;
	while (temp < -58 || temp >41)
	{
		cout << " the temparature you entered is not within the defined range, Please enter a different temperature that is greater than -58 F and smaller than 41 F:";
		cin >> temp;
	}
	cout << "please enter the wind speed in miles per hour( wind speed needs to ber greater than 2 m/h):";
	cin >> wspeed;
	while (wspeed < 2)
	{
		cout << " the wind speed you entered is not in the defined range, please enter a different wind speed greater than 2 m/h: ";
		cin >> wspeed;
	}
	cout << "wind-chill temparature (in Farenhait) for the given values of wind speed and temparature is: " << windChill(temp, wspeed);
}
