/* Lab 5-Problem #1 even odd
 even_odd.cpp: we will write a function that helps us determine if a integer is odd or even.
 Author: Iddo Sadeh Date: October 9, 2020*/
#include <iostream>
#include <cmath> /* here we include cmath to import the library which will let us usefunctions such as M_PI and pow*/
#include <iomanip> /*here we import the library which includes functions such as setpercision() and fixed*/
#include <stdlib.h>  // here we import a library that lets us use the rand funciton
#include <ctime> // here we import a library that will let us use time() function
#include<string> // here we import a library that will let us use functions such as getLine()
#include <fstream>// here we import a library which lets us read and write files

using namespace std;


string evenOrOdd(int a) //Parameter is int, Returned Value is of type string
{
	if (a % 2 == 0)
		return " even";
	else
		return " odd";
}


int main()
{
	int b;
	cout << "in this program we will help you determine if an integer is even or odd" << endl << "Please enter your integer:";
	cin >> b;
	cout << b << " is" << evenOrOdd(b);

}
