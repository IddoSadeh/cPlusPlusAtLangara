/* Lab 5-Problem #5 encoding
 encoding.cpp: we will Write a function, called encodeString, which receives a string as parameter, replaces the characters  O/o L/l B/b with 0 1 8 respectivelly, and returns the new string. 
 Author: Iddo Sadeh Date: October 9, 2020*/
#include <iostream>
#include <cmath> /* here we include cmath to import the library which will let us usefunctions such as M_PI and pow*/
#include <iomanip> /*here we import the library which includes functions such as setpercision() and fixed*/
#include <stdlib.h>  // here we import a library that lets us use the rand funciton
#include <ctime> // here we import a library that will let us use time() function
#include <string> // here we import a library that will let us use functions such as getLine()
#include <fstream>// here we import a library which lets us read and write files

using namespace std;

string encodeString(string a)
{
	int b = a.length();
	for (int i = 0; i < b; i++)
	{
		if (a[i] == 'o' || a[i] == 'O')
			a[i] = '0';
		else if (a[i] == 'L' || a[i] == 'l')
			a[i] = '1';
		else if (a[i] == 'B' || a[i] == 'b')
			a[i] = '8';
	}
	return a;
}



int main()
{
	string userinput;
	cout << "please  enter a string (word) and this program will return an encoded version of it"<<endl;
	getline(cin, userinput);
	cout << encodeString(userinput);
}
