/* Lab 5-Problem #4 sum odd places
 sum_odd_places.cpp: we will write a function that helps us return the sum of digits in the odd places in an integer
 Author: Iddo Sadeh Date: October 9, 2020*/
#include <iostream>
#include <cmath> /* here we include cmath to import the library which will let us usefunctions such as M_PI and pow*/
#include <iomanip> /*here we import the library which includes functions such as setpercision() and fixed*/
#include <stdlib.h>  // here we import a library that lets us use the rand funciton
#include <ctime> // here we import a library that will let us use time() function
#include<string> // here we import a library that will let us use functions such as getLine()
#include <fstream>// here we import a library which lets us read and write files

using namespace std;

int count_numbers(int num) //function to check length of number
{
	int count = 0;
	while (num != 0) // as long as number is not 0 we add 1 to cariable count
	{
		count++;
		num /= 10; // every loop we "remove" the last digit to make number smaller, we repeat until num=0
	}
	return count;
}

int sumOfOddPlaces(int n)
{
	int sum = 0;
	while (count_numbers(n) != 0) //to count the sum of odd digits we will divide the number we got by 10 (or 100 if number is odd) every loop, as long as the number is not 0 the loop continues
	{
		if (count_numbers(n) % 2 == 1) //if length of number is odd
		{

			sum = sum + n % 10; // we take the last digit of the number and place in variable sum
			n = n / 100; // we divide number by 100 so we can repeat the loop with the next odd number

		}
		else // if number is even we will turn it to odd so we can ub to the if statement
		{
			n = n / 10;

		}

	}

	return sum;
}




int main()
{
	int a;
	cout << "this program will return the sum of the numbers in the odd places of your integer, please enter a number: ";
	cin >> a;
	cout << "the sum of the numbers of in the odd places of your integer is: " << sumOfOddPlaces(a);
}
