//----------------------------------------------------------------------------
// Lab 1-B: Working with an online tool
// printName.cpp: This program asks for your name and greets you!
//
// Author:Iddo, 5195       Date: 09/11/2020
//-----------------------------------------------------------------------------
#include <iostream>
#include <string>
using namespace std;
 
int main() {
 
string name; // Declare a variable for your name
 
 
cout << "Please enter your name: "; // Ask for the input
 
cin >> name;
 
cout << "Hello " << name << endl; // A greeting is printed
 
 
return 0;  
 
} // End main
