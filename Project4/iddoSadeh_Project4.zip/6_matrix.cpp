/* Project 4 - Problem 6 (8.9 in textbook) Algebra: multiply two matrices
 6_matrix.cpp
description: we wil Write a test program that prompts the user to enter two 3 * 3 matrices and displays their product
 Author: Iddo Sadeh Date: Novemeber 15, 2020*/
#include <iostream>
#include <cmath> /* here we include cmath to import the library which will let us usefunctions such as M_PI and pow*/
#include <iomanip> /*here we import the library which includes functions such as setpercision() and fixed*/
#include <stdlib.h>  // here we import a library that lets us use the rand funciton
#include <ctime> // here we import a library that will let us use time() function
#include <cstring> // here we import a library that will let us use functions such as getLine()
#include <fstream> // here we import a library which lets us read and write files

using namespace std;
const int N = 3;
void multiplyMatrix(const double a[][N], const double b[][N], double c[][N])
{
	for (int i = 0; i < N; i++)
	{
		for (int j = 0; j < N; j++)
		{
			c[i][j] = ((a[i][0] * b[0][j]) + (a[i][1] * b[1][j]) + (a[i][2] * b[2][j]));
		}
	}
	cout << "the product of the two matrices is: " << endl;
	for (int i = 0; i < N; i++)
	{
		for (int j = 0; j < N; j++)
		{
			cout << setw(5) << a[i][j];
		}
		if (i == 1)
		{
			cout << " *";
		}
		else
		{
			cout << "  ";
		}
		for (int j = 0; j < N; j++)
		{
			cout << setw(5) << b[i][j];
		}
		if (i == 1)
		{
			cout << " =";
		}
		else
		{
			cout << "  ";
		}
		for (int j = 0; j < N; j++)
		{
			cout << setw(7) << c[i][j];
		}
		cout << endl;
	}
}
int main()
{
	double a[N][N], b[N][N], c[N][N];
	cout << "enter two marices, row by row, and we will display the product of the two" << endl;
	cout << "Matrix1: " << endl;
	for (int i = 0; i < N; i++)
	{
		for (int j = 0; j < N; j++)
		{
			cin >> a[i][j];
		}
	}
	cout << "Matrix2: ";
	for (int i = 0; i < N; i++)
	{
		for (int j = 0; j < N; j++)
		{
			cin >> b[i][j];
		}
	}
	multiplyMatrix(a, b, c);

}
