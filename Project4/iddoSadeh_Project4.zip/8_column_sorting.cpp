/* Project 4 - Problem 8 (8.27 in textbook) Column sorting
 8_column_sorting.cpp
description: we will sort the columns in a two dimensional array
 Author: Iddo Sadeh Date: Novemeber 15, 2020*/
#include <iostream>
#include <cmath> /* here we include cmath to import the library which will let us usefunctions such as M_PI and pow*/
#include <iomanip> /*here we import the library which includes functions such as setpercision() and fixed*/
#include <stdlib.h>  // here we import a library that lets us use the rand funciton
#include <ctime> // here we import a library that will let us use time() function
#include <string> // here we import a library that will let us use functions such as getLine()
#include <fstream> // here we import a library which lets us read and write files

using namespace std;

const int SIZE = 3;
void selectionSort(double list[], int listSize)
{
	for (int i = 0; i < listSize - 1; i++)
	{
		// Find the minimum in the list[i..listSize-1]
		double currentMin = list[i];
		int currentMinIndex = i;

		for (int j = i + 1; j < listSize; j++)
		{
			if (currentMin > list[j])
			{
				currentMin = list[j];
				currentMinIndex = j;
			}
		}

		// Swap list[i] with list[currentMinIndex] if necessary;
		if (currentMinIndex != i)
		{
			list[currentMinIndex] = list[i];
			list[i] = currentMin;
		}
	}
}
void sortColumns(const double m[][SIZE], double result[][SIZE])
{

	double list[3];
	for (int i = 0; i < SIZE; i++)
	{
		for (int j = 0; j < SIZE; j++)
		{
			list[j] = m[j][i];
		}
		selectionSort(list, SIZE);
		for (int k = 0; k < SIZE; k++)
		{
			result[k][i] = list[k];
		}
	}
	cout << "The column-sorted array is " << endl;
	for (int i = 0; i < SIZE; i++)
	{
		for (int j = 0; j < SIZE; j++)
		{
			cout << result[i][j] << " ";
		}
		cout << endl;
	}


}
int main()
{
	double m[3][3], result[3][3];

	cout << "enter  a 3 * 3 two-dimensional array, row by row, and we will display a column sorted array" << endl;
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			cin >> m[i][j];
		}
		cout << endl;
	}
	sortColumns(m, result);

}
