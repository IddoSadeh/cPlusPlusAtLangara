/* Project 4 - Problem 7 (8.17 in textbook) Locate the largest element
 7_locate_largest.cpp
description: we will Write a function that finds the location of the largest element in a two-dimensional array.
 Author: Iddo Sadeh Date: Novemeber 15, 2020*/
#include <iostream>
#include <cmath> /* here we include cmath to import the library which will let us usefunctions such as M_PI and pow*/
#include <iomanip> /*here we import the library which includes functions such as setpercision() and fixed*/
#include <stdlib.h>  // here we import a library that lets us use the rand funciton
#include <ctime> // here we import a library that will let us use time() function
#include <string> // here we import a library that will let us use functions such as getLine()
#include <fstream> // here we import a library which lets us read and write files

using namespace std;

void locateLargest(const double a[][4], int location[])
{
	int x = 0;
	for (int i = 0; i < 3; i++)
	{

		for (int j = 0; j < 4; j++)
		{
			if (a[i][j] > x)
			{
				x = a[i][j];
				location[0] = i;
				location[1] = j;
			}

		}
	}
}
int main()
{
	double a[3][4];
	int location[2] = { 0,0 };
	cout << "enter  a 3 * 4 two-dimensional array, row by row, and we will display the indices of the largest element in the array" << endl;
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			cin >> a[i][j];
		}
		cout << endl;
	}

	locateLargest(a, location);

	cout << "The location of the largest element is at " << location[0] << " , " << location[1];
}
