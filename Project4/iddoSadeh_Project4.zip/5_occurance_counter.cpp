/* Project 4 - Problem 5 (7.37 in textbook) Count occurrence of each letter in a string
 5_occurance_counter.cpp
description: we wil l Write a function that counts the occurrence of each letter in a string
 Author: Iddo Sadeh Date: Novemeber 15, 2020*/
#include <iostream>
#include <cmath> /* here we include cmath to import the library which will let us usefunctions such as M_PI and pow*/
#include <iomanip> /*here we import the library which includes functions such as setpercision() and fixed*/
#include <stdlib.h>  // here we import a library that lets us use the rand funciton
#include <ctime> // here we import a library that will let us use time() function
#include <cstring> // here we import a library that will let us use functions such as getLine()
#include <fstream> // here we import a library which lets us read and write files

using namespace std;
void count(const char s[], int counts[])
{
	for (int i = 0; i < strlen(s); i++)
	{
		if (s[i] > 96 && s[i] < 123)
		{
			counts[s[i] - 97]++;
		}
		else if (s[i] > 64 && s[i] < 91)
		{
			counts[s[i] - 65]++;
		}
	}
	for (int j = 0; j < 26; j++)
	{
		if (counts[j] != 0)
		{
			cout << char(j + 65) << " occurs " << counts[j] << " times " << endl;
		}
	}
}
int main()
{
	int counts[26] = {};
	char s[50];
	cout << "enter a string and we will return the sum of occurence of each letter" << endl;
	cin.getline(s, 50, '\n');
	count(s, counts);

}
