/* Project 4 - Problem 2 (7.7 in textbook) Sum of Even random numbers
2_Sum_of_Even_random_numbers.cpp
description: we will write a program that generates twenty five random integers between 0 and 25 and displays the sum of even integers
 Author: Iddo Sadeh Date: Novemeber 15, 2020*/
#include <iostream>
#include <cmath> /* here we include cmath to import the library which will let us usefunctions such as M_PI and pow*/
#include <iomanip> /*here we import the library which includes functions such as setpercision() and fixed*/
#include <stdlib.h>  // here we import a library that lets us use the rand funciton
#include <ctime> // here we import a library that will let us use time() function
#include <string> // here we import a library that will let us use functions such as getLine()
#include <fstream> // here we import a library which lets us read and write files

using namespace std;

int main()
{
    srand(time(NULL));
    int random[25];
    int sum = 0;

    int counter = 0;
    cout << "random integers between 0 and 25: ";
    for (int i = 0; i < 25; i++)
    {

        random[i] = rand() % 25;
        cout << random[i] << ", ";
        if (random[i] % 2 == 0)
        {
            sum += random[i];
        }


    }

    cout << endl << "sum of the even integers is " << sum << endl;
}
