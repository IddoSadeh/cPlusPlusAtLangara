/* Project 4 - Problem 4 (7.27 in textbook) sorted?
 4_is_sorted.cpp
description: we will Write a test program that prompts the user to enter a list and displays whether the list is sorted or not
 Author: Iddo Sadeh Date: Novemeber 15, 2020*/
#include <iostream>
#include <cmath> /* here we include cmath to import the library which will let us usefunctions such as M_PI and pow*/
#include <iomanip> /*here we import the library which includes functions such as setpercision() and fixed*/
#include <stdlib.h>  // here we import a library that lets us use the rand funciton
#include <ctime> // here we import a library that will let us use time() function
#include <string> // here we import a library that will let us use functions such as getLine()
#include <fstream> // here we import a library which lets us read and write files

using namespace std;
double isSorted(const int list[], int size)
{
	for (int i = 1; i < size; i++)
	{
		if (list[i] < list[i - 1])
		{
			return false;
		}

	}
	return true;
}
int main()
{
	int input[80], a;
	cout << "enter digits and we will check if they are sorted in ascending order or not" << endl;
	cout << "first enter the size of your list: ";
	cin >> a;
	for (int i = 0; i < a; i++)
	{
		cin >> input[i];
	}
	if (isSorted(input, a))
		cout << "The list is sorted";
	else
		cout << "the list is not sorted";
}
