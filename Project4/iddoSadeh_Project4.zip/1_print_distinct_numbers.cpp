/* Project 4 - Problem 1 (7.5 in textbook) Print distinct numbers
print_distinct_numbers.cpp
description: we  Write a program that reads in 10 numbers and displays distinct numbers
 Author: Iddo Sadeh Date: Novemeber 15, 2020*/
#include <iostream>
#include <cmath> /* here we include cmath to import the library which will let us usefunctions such as M_PI and pow*/
#include <iomanip> /*here we import the library which includes functions such as setpercision() and fixed*/
#include <stdlib.h>  // here we import a library that lets us use the rand funciton
#include <ctime> // here we import a library that will let us use time() function
#include <string> // here we import a library that will let us use functions such as getLine()
#include <fstream>// here we import a library which lets us read and write files

using namespace std;
int main()
{
    int input[10], output[10];
    int a, counter1 = 0, counter2 = 0;
    cout << "enter 10 digits and we will return the distinct digits" << endl;
    for (int i = 0; i < 10; i++)
    {
        cin >> a;
        input[i] = a;
    }
    for (int j = 0; j < 10; j++)
    {
        for (int k = 0; k < 10; k++)
        {
            if (input[j] == output[k])
            {
                counter1++;
            }
        }
        if (counter1 == 0)
        {
            output[counter2] = input[j];
            cout << output[counter2] << endl;
            counter2++;


        }
        counter1 = 0;
    }

}
