/* Project 4 - Problem 3 (7.11 in textbook) Statistics: compute deviation
 3_compute_deviation.cpp
description: we will  Write a test program that prompts the user to enter 10 numbers and displays the mean and deviation
 Author: Iddo Sadeh Date: Novemeber 15, 2020*/
#include <iostream>
#include <cmath> /* here we include cmath to import the library which will let us usefunctions such as M_PI and pow*/
#include <iomanip> /*here we import the library which includes functions such as setpercision() and fixed*/
#include <stdlib.h>  // here we import a library that lets us use the rand funciton
#include <ctime> // here we import a library that will let us use time() function
#include <string> // here we import a library that will let us use functions such as getLine()
#include <fstream> // here we import a library which lets us read and write files

using namespace std;
double mean(const double x[], int size)
{
    double sum = 0.0;
    for (int i = 0; i < size; i++) {
        sum += x[i];
    }
    return (sum / size);
}
double deviation(const double x[], int size)
{
    double sqr_sum = 0.0, mean_v;
    double sum = 0.0;
    mean_v = mean(x, size);
    for (int i = 0; i < size; i++)
    {
        sqr_sum += pow((x[i] - mean_v), 2);
    }
    double variance = sqr_sum / (size - 1.0);
    return (sqrt(variance));

}
int main()
{
    double input[10];
    int a;
    cout << "enter 10 digits and we will return the mean and deviation" << endl;
    for (int i = 0; i < 10; i++)
    {
        cin >> input[i];

    }
    cout << "the mean is " << mean(input, 10) << endl << "the standard deviation is " << deviation(input, 10);
}
