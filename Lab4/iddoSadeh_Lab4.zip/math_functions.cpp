/* Lab 4-Problem # 1 math functions
math_functions.cpp: description: in this program the user inputs a number,
we will calculate the following expression k using C++ mathematical functions,
k =e^-x + e^-0.5x +e^-x^0.5 +(e^x)/x
and display the results with 6 digits after the decimal point.
Author: Iddo Sadeh Date: October 2, 2020*/


#define _USE_MATH_DEFINES // here we declares a preprocessor macro to allow us to include math constants
#include <iostream>
#include <cmath> /* here we include cmath to import the library which will let us usefunctions such as M_PI and pow*/
#include <iomanip> /*here we import the library which includes functions such as setpercision() and fixed*/

using namespace std;

int main()
{
    double x, k;
    cout << "please enter a value and we will return te value of k according to the equation k =e^-x + e^-0.5x +e^-x^0.5 +(e^x)/x where x is your input: ";
    cin >> x;
    while (x == 0)
    {
        cout << "the number you entered is invlaid please try again";
        cin >> x;
    }

    k = exp(-x) + exp(-0.5 * x) + exp(-pow(x, 0.5)) + exp(x) / x;
    cout << fixed << setprecision(6) << k;

}
