/* Lab 4-Problem # 3 Strings
strings.cpp:
description: in this program the user will input the first name, last name, and grade for a student
we will display the results in a tablewith column width  12 and the text  left-aligned, The first row will ne the heading.
we will ask the user to enter values for the second row.
 The program tests the validity of the grade (between 0 and 100)
Author: Iddo Sadeh Date: October 2, 2020*/


#define _USE_MATH_DEFINES // here we declares a preprocessor macro to allow us to include math constants
#include <iostream>
#include <cmath> /* here we include cmath to import the library which will let us usefunctions such as M_PI and pow*/
#include <iomanip> /*here we import the library which includes functions such as setpercision() and fixed*/
#include <stdlib.h>  // here we import a library that lets us use the rand funciton
#include <ctime> // here we import a library that will let us use time() function
#include<string> // here we import a library that will let us use functions such as getLine()
using namespace std;

int main()
{
    string firstName, lastName;
    double grade;

    cout << "This program will organize your grades in a table, please start by entering your first name: " << endl;
    getline(cin, firstName);
    cout << "Now enter your last name: " << endl;
    getline(cin, lastName);
    cout << "Now enter Grade: ";
    cin >> grade;
    while (grade < 0 || grade >100)
    {
        cout << "The grade you entered isnt valid, please enter a new grade: " << endl;
        cin >> grade;
    }
    cout << endl;
    cout << left << setw(12) << "First Name" << setw(12) << "Last Name" << setw(12) << "Grade" << endl;
    cout << left << setw(12) << firstName << setw(12) << lastName << setw(12) << grade << endl;
    return 0;
}
