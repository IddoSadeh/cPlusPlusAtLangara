/* Lab 4-Problem # 2C charactersC
charactersC.cpp: description: in this program we will generate and display two random letters; one lowercase and one uppercase
Author: Iddo Sadeh Date: October 2, 2020*/


#define _USE_MATH_DEFINES // here we declares a preprocessor macro to allow us to include math constants
#include <iostream>
#include <cmath> /* here we include cmath to import the library which will let us usefunctions such as M_PI and pow*/
#include <iomanip> /*here we import the library which includes functions such as setpercision() and fixed*/
#include <stdlib.h>  // here we import a library that lets us use the rand funciton
#include <ctime> // here we import a library that will let us use time() function

using namespace std;

int main()
{
	srand(time(0));
	char a = rand() % 26 + 65;
	char b = rand() % 26 + 97;
	cout << a << " is a uppercase letter and " << b << " is a lowercase letter";
	return 0;
}

