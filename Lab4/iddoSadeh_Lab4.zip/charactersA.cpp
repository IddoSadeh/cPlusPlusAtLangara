/* Lab 4-Problem # 2A charactersA
charactersA.cpp: description: in this program we will Receive an 8-bit ASCII code
(an integer between 0 and 255) and displays the equivalent character
Author: Iddo Sadeh Date: October 2, 2020*/


#define _USE_MATH_DEFINES // here we declares a preprocessor macro to allow us to include math constants
#include <iostream>
#include <cmath> /* here we include cmath to import the library which will let us usefunctions such as M_PI and pow*/
#include <iomanip> /*here we import the library which includes functions such as setpercision() and fixed*/

using namespace std;

int main()
{
	int a;
	cout << "Please enter a 8-bit ASCII code (integer between 0 and 255) ";
	cin >> a;
	while (a < 0 || a>255)
	{
		cout << "the number you entered is not in the defined range, Please enter a new number ";
		cin >> a;
	}
	cout << char(a);
	return 0;
}

