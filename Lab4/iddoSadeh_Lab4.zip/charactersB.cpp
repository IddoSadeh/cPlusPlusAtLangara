/* Lab 4-Problem # 2B charactersB
charactersB.cpp: description: in this program the user will input a character
we than check if it is a lowercase or uppercase letter
and display the result and its equivalent ASCII code in decimal.
Author: Iddo Sadeh Date: October 2, 2020*/


#define _USE_MATH_DEFINES // here we declares a preprocessor macro to allow us to include math constants
#include <iostream>
#include <cmath> /* here we include cmath to import the library which will let us usefunctions such as M_PI and pow*/
#include <iomanip> /*here we import the library which includes functions such as setpercision() and fixed*/

using namespace std;

int main()
{
	char a;
	cout << "Please enter a letter, we will check if its an uppercase or lowecase letter and return the equivalent ASCII number ";
	cin >> a;
	while (a < 65 || a < 97 && a>90 || a>122)
	{
		cout << "the character you entered is not a letter, Please enter a new letter ";
		cin >> a;
	}
	if (64 < a && a < 91)
	{

		cout << a << " is a uppercase letter and its ASCII number is " << int(a);
	}
	else
	{
		cout << a << " is a lowercase letter and its ASCII number is " << int(a);
	}
	return 0;
}

