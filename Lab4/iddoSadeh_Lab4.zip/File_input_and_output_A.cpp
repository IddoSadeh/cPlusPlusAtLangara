/* Lab 4-Problem # 4A File input and output A
File_input_and_output_A.cpp:
description: in this program we will write the grades for 3 students to a local file
Author: Iddo Sadeh Date: October 2, 2020*/


#define _USE_MATH_DEFINES // here we declares a preprocessor macro to allow us to include math constants
#include <iostream>
#include <cmath> /* here we include cmath to import the library which will let us usefunctions such as M_PI and pow*/
#include <iomanip> /*here we import the library which includes functions such as setpercision() and fixed*/
#include <stdlib.h>  // here we import a library that lets us use the rand funciton
#include <ctime> // here we import a library that will let us use time() function
#include<string> // here we import a library that will let us use functions such as getLine()
#include <fstream>// here we import a library which lets us read and write files
using namespace std;

int main()
{
    ofstream output;
    output.open("grades.txt");
    double grade1, grade2, grade3;
    cout << "This program will let you save the grades of 3 students in to a file, please enter the first grade: ";
    cin >> grade1;
    while (grade1 < 0 || grade1 >100)
    {
        cout << "The grade you entered isnt valid, please enter a new grade: " << endl;
        cin >> grade1;
    }
    cout << "Please enter the second grade: ";
    cin >> grade2;
    while (grade2 < 0 || grade2 >100)
    {
        cout << "The grade you entered isnt valid, please enter a new grade: " << endl;
        cin >> grade2;
    }
    cout << "Please enter the third grade: ";
    cin >> grade3;
    while (grade3 < 0 || grade3 >100)
    {
        cout << "The grade you entered isnt valid, please enter a new grade: " << endl;
        cin >> grade3;
    }
    output << left << setw(12) << grade1 << setw(12) << grade2 << setw(12) << grade3 << endl;
    return 0;
}
