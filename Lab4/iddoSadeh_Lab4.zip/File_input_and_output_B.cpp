/* Lab 4-Problem # 4B File input and output B
File_input_and_output_B.cpp:
description: in this program we will read the grades from the local file created in the previous excersise
Author: Iddo Sadeh Date: October 2, 2020*/


#define _USE_MATH_DEFINES // here we declares a preprocessor macro to allow us to include math constants
#include <iostream>
#include <cmath> /* here we include cmath to import the library which will let us usefunctions such as M_PI and pow*/
#include <iomanip> /*here we import the library which includes functions such as setpercision() and fixed*/
#include <stdlib.h>  // here we import a library that lets us use the rand funciton
#include <ctime> // here we import a library that will let us use time() function
#include<string> // here we import a library that will let us use functions such as getLine()
#include <fstream>// here we import a library which lets us read and write files
using namespace std;

int main()
{
    ifstream input;
    input.open("grades.txt");
    double grade1, grade2, grade3;
    input >> grade1 >> grade2 >> grade3;
    cout << "this program fetches the grades from grades.txt and display them: " << endl;
    cout << grade1 << " " << grade2 << " " << grade3;
    return 0;
}
